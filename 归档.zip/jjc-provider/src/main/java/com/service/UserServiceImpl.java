package com.service;


import com.alibaba.dubbo.config.annotation.Service;
import org.springframework.stereotype.Component;
import service.UserService;

@Service
@Component
public class UserServiceImpl implements UserService {

    @Override
    public String getAddress(String uesrId) {
        return "我是生产者";
    }
}
