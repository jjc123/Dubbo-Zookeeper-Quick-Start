package service;


public interface UserService {
    String getAddress(String userId);
}
