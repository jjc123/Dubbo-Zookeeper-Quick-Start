package com.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.dubbo.config.annotation.Service;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import service.UserService;

import javax.annotation.Resource;

/**
 * 〈〉
 *
 * @author apple
 * @create 2020/5/31
 * @since 1.0.0
 */
@Controller
public class OrderController {

    @Reference
    UserService userService;

    @ResponseBody
    @GetMapping("/get")
    public String initOrder(String id) {
        String name = userService.getAddress(id);
        return name;
    }
}
